//
//  IMBHorizontalSlideMenu.m
//  IMBFramework
//
//  Created by Tai Duong on 12/8/16.
//  Copyright © 2016 Tai Duong. All rights reserved.
//

#import "IMBHorizontalSlideMenu.h"

#pragma mark UIColor Custom
@implementation UIColor (Custom)
+(instancetype)r:(CGFloat)red g:(CGFloat)green b:(CGFloat)blue
{
    return [UIColor colorWithRed:red/255 green:green/255 blue:blue/255 alpha:1];
}
+(instancetype)r:(CGFloat)red g:(CGFloat)green b:(CGFloat)blue a:(CGFloat)alpha
{
    return [UIColor colorWithRed:red/255 green:green/255 blue:blue/255 alpha:alpha];
}
@end

#pragma mark UIView Custom
@implementation UIView (Custom)
-(void)addConstraintsWithFormat:(NSString *)format andViews: (NSArray *)arrOfViews
{
    NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
    for (UIView *view in arrOfViews)
    {
        view.translatesAutoresizingMaskIntoConstraints = NO;
        NSString *key = [[NSString alloc] initWithFormat:@"v%li",[arrOfViews indexOfObject:view]];
        [dic setObject:view forKey:key];
    }
    [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:format options:0 metrics:nil views:dic]];
}
-(void)addConstraintsWithFormat:(NSString *)format andView:(UIView *)view
{
    NSString *key = @"v0";
    view.translatesAutoresizingMaskIntoConstraints = NO;
    [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:format options:0 metrics:nil views:@{key: view}]];
}
@end

#pragma mark HorizontalSlideCell
@interface HorizontalSlideCell()
@property (nonatomic) NSString *nameOfIcon;
@property UIColor *iconSelectedTintColor;
@property UIColor *iconHighlitedTintColor;
@property UIColor *iconUnSelectedTintColor;
@property CGSize sizeOfIcon;

@end

@implementation HorizontalSlideCell
@synthesize iconView;
-(void)setUp
{
    iconView = [[UIImageView alloc] init];
    iconView.image = [[UIImage imageNamed:self.nameOfIcon] imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
    iconView.tintColor = self.iconUnSelectedTintColor;
    [self.contentView addSubview:iconView];
    iconView.translatesAutoresizingMaskIntoConstraints = NO;
    [[iconView.centerYAnchor constraintEqualToAnchor:self.contentView.centerYAnchor] setActive:YES];
    [[iconView.centerXAnchor constraintEqualToAnchor:self.contentView.centerXAnchor] setActive:YES];
    [[iconView.widthAnchor constraintEqualToConstant:self.sizeOfIcon.width] setActive:YES];
    [[iconView.heightAnchor constraintEqualToConstant:self.sizeOfIcon.height] setActive:YES];
}
-(void)setHighlighted:(BOOL)highlighted
{
    iconView.tintColor = highlighted ? self.iconHighlitedTintColor : self.iconUnSelectedTintColor;
}
-(void)setSelected:(BOOL)selected
{
    iconView.tintColor = selected ? self.iconSelectedTintColor : self.iconUnSelectedTintColor;
}
@end


#pragma mark IMBHORIZONTALSLIDEMENU
@implementation IMBHorizontalSlideMenu
{
    UIView *horizontalBar;
    NSString *cellID;
    NSArray *arrOfIconsNames;
}
//
-(instancetype)init
{
    self = [super init];
    return self;
}
#pragma mark SETUP
-(void)setUp
{
    cellID = @"cellID";
    
    arrOfIconsNames = [self.dataSource arrOfIconsNamesForCells];
    self.delegateCollectionView = [self.delegate setCollectionViewForMenuSlideBar];
    self.widthOfBar = [self.flowLayout widthForBar];
    NSLog(@"%.f",self.widthOfBar);
    self.numberOfItems = arrOfIconsNames.count;
    
    [self setHorizontalBar];
    [self setUpCollectionView];
    
    
    [self addSubview:horizontalBar];
    [self addSubview:self.collectionView];
    NSString* format = [[NSString alloc] initWithFormat:@"V:|[v0][v1(%.f)]|",self.widthOfBar];
    [self addConstraintsWithFormat:@"H:|[v0]|" andView:self.collectionView];
    [self addConstraintsWithFormat:format andViews:@[self.collectionView, horizontalBar]];
    
    
    [[horizontalBar.widthAnchor constraintEqualToAnchor:self.collectionView.widthAnchor multiplier:0.2] setActive:YES];
    self.leftConstraint = [horizontalBar.leftAnchor constraintEqualToAnchor:self.leftAnchor];
    [self.leftConstraint setActive:YES];

}
-(void)setHorizontalBar
{
    horizontalBar = [[UIView alloc] init];
}

#pragma mark COLLECTIONVIEW
-(void)setUpCollectionView
{
    UICollectionViewFlowLayout *flowLayout = [[UICollectionViewFlowLayout alloc] init];
    self.collectionView = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:flowLayout];
    self.collectionView.backgroundColor = [UIColor clearColor];
    self.collectionView.delegate = self;
    self.collectionView.dataSource = self;
    [self.collectionView registerClass:[HorizontalSlideCell class] forCellWithReuseIdentifier:cellID];
}

-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    self.backgroundColor = [UIColor r:116 g:192 b:241];
    HorizontalSlideCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:cellID forIndexPath:indexPath];
    NSInteger index = indexPath.item;
    if (arrOfIconsNames.count <= index) cell.nameOfIcon = @"";
    else cell.nameOfIcon = [arrOfIconsNames objectAtIndex:index];

    self.iconHighlitedTintColor = (self.iconHighlitedTintColor != nil) ? self.iconHighlitedTintColor : [UIColor whiteColor];
    
    self.iconSelectedTintColor = self.iconSelectedTintColor != nil ? self.iconSelectedTintColor : [UIColor whiteColor];
    
    self.iconUnSelectedTintColor = self.iconUnSelectedTintColor != nil ? self.iconUnSelectedTintColor : [UIColor darkGrayColor];
    
    horizontalBar.backgroundColor = self.horizontalBarTintColor != nil ? self.horizontalBarTintColor : [UIColor blueColor];
    
    cell.iconUnSelectedTintColor = self.iconUnSelectedTintColor;
    cell.iconSelectedTintColor = self.iconSelectedTintColor;
    cell.iconHighlitedTintColor = self.iconHighlitedTintColor;
    
    cell.sizeOfIcon = [self.flowLayout sizeForIconAtItem:indexPath.item];
    [cell setUp];
    if (indexPath.item == 0)
    {
        cell.iconView.tintColor = self.iconSelectedTintColor;
    }
    cell.backgroundColor = [UIColor clearColor];
    return cell;
}
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{

    [self.delegateCollectionView scrollToItemAtIndexPath:indexPath atScrollPosition:UICollectionViewScrollPositionNone animated:YES];
    NSArray *arrayOfCells = [self.collectionView visibleCells];
    for (HorizontalSlideCell *item in arrayOfCells)
    {
        if ([arrayOfCells indexOfObject:item] != indexPath.item)
        {
            item.iconView.tintColor = self.iconUnSelectedTintColor;
        }
    }
    
}
-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return 1;
}

-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return arrOfIconsNames.count;
}


-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    CGFloat width = round(self.collectionView.frame.size.width/self.numberOfItems) - 1;
    CGFloat height = self.collectionView.frame.size.height;
    NSLog(@"w: %f, h: %f", width, height);
    return CGSizeMake(width, height);
}
-(CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section
{
    return 0;
}

#pragma mark Scroll Bar and select item
-(void)scrollBarAndSelectItemWithContentOffSet:(CGPoint)contentOffSet andWidthOfCell:(CGFloat)width
{
    float index = contentOffSet.x/width;
    NSLog(@"%.f",index);
    NSIndexPath *indexPath = [NSIndexPath indexPathForItem:roundf(index) inSection:0];
    [self.collectionView selectItemAtIndexPath:indexPath animated:YES scrollPosition:UICollectionViewScrollPositionNone];
    NSArray *arrayOfCells = [self.collectionView visibleCells];
    for (HorizontalSlideCell *item in arrayOfCells)
    {
        if ([arrayOfCells indexOfObject:item] != indexPath.item)
        {
            item.iconView.tintColor = self.iconUnSelectedTintColor;
        }
    }
}

-(void)scrollBarWithContentOffSet:(CGPoint)contentOffSet;
{
    
    [self.leftConstraint setConstant:contentOffSet.x/self.numberOfItems];
}
@end
