//
//  IMBHorizontalSlideMenu.h
//  IMBFramework
//
//  Created by Tai Duong on 12/8/16.
//  Copyright © 2016 Tai Duong. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol IMBHorizontalSlideMenuDelegate
@required
-(UICollectionView *)setCollectionViewForMenuSlideBar;
@end

@protocol IMBHorizontalSlideMenuFlowLayout
@required
-(CGSize )sizeForIconAtItem:(NSInteger)item;
-(CGFloat )widthForBar;
@end

@protocol IMBHorizontalSlideMenuDataSource
@required
-(NSArray *)arrOfIconsNamesForCells;
@end

@interface IMBHorizontalSlideMenu : UIView <UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout>
@property (weak) id <IMBHorizontalSlideMenuDelegate> delegate;
@property (weak) id <IMBHorizontalSlideMenuDataSource> dataSource;
@property (weak) id <IMBHorizontalSlideMenuFlowLayout> flowLayout;
@property (nonatomic) UICollectionView *collectionView;
@property (nonatomic) UICollectionView *delegateCollectionView;
@property NSInteger numberOfItems;
@property UIColor *horizontalBarTintColor;
@property UIColor *iconSelectedTintColor;
@property UIColor *iconHighlitedTintColor;
@property UIColor *iconUnSelectedTintColor;
@property CGSize sizeOfIcon;
@property CGFloat widthOfBar;
@property NSLayoutConstraint *leftConstraint;
@property NSInteger defaultSelectedIndex;
-(void)setUp;
-(void)scrollBarAndSelectItemWithContentOffSet:(CGPoint)contentOffSet andWidthOfCell:(CGFloat)width;
-(void)scrollBarWithContentOffSet:(CGPoint)contentOffSet;
@end

@interface UIView (Custom)
-(void)addConstraintsWithFormat:(NSString *)format andViews:(NSArray *)arrOfViews;
-(void)addConstraintsWithFormat:(NSString *)format andView:(UIView *)view;
@end
@interface UIColor (Custom)
+(instancetype) r:(CGFloat)red g:(CGFloat)green b:(CGFloat)blue;
+(instancetype) r:(CGFloat)red g:(CGFloat)green b:(CGFloat)blue a:(CGFloat)alpha;
@end
@interface HorizontalSlideCell : UICollectionViewCell
@property UIImageView *iconView;
@end

