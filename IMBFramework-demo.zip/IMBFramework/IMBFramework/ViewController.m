//
//  ViewController.m
//  IMBFramework
//
//  Created by Dung Duong on 12/8/16.
//  Copyright © 2016 Tai Duong. All rights reserved.
//

#import "ViewController.h"
#import "IMBHorizontalSlideMenu.h"

@interface ViewController ()<IMBHorizontalSlideMenuDelegate, IMBHorizontalSlideMenuDataSource, IMBHorizontalSlideMenuFlowLayout, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout>

@end

@implementation ViewController
{
    IMBHorizontalSlideMenu *horizontalSlideMenu;
    UICollectionView *temp;
}
-(void)viewWillTransitionToSize:(CGSize)size withTransitionCoordinator:(id<UIViewControllerTransitionCoordinator>)coordinator
{
    [horizontalSlideMenu.collectionView.collectionViewLayout invalidateLayout];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    self.automaticallyAdjustsScrollViewInsets = NO;
    
    horizontalSlideMenu = [[IMBHorizontalSlideMenu alloc] init];
    [self setUpCollectionView];
    [self.view addSubview:horizontalSlideMenu];
    [self.view addSubview:temp];
    
    [self.view addConstraintsWithFormat:@"V:|-20-[v0(60)][v1]|" andViews:@[horizontalSlideMenu, temp]];
    [self.view addConstraintsWithFormat:@"H:|-0-[v0]-0-|" andView:horizontalSlideMenu];
    [self.view addConstraintsWithFormat:@"H:|-0-[v0]-0-|" andView:temp];
    
    [self setUpHorizontalSlideMenu];
}
-(void)setUpHorizontalSlideMenu
{
    
    horizontalSlideMenu.delegate = self;
    horizontalSlideMenu.dataSource = self;
    horizontalSlideMenu.flowLayout = self;
    [horizontalSlideMenu setUp];
    
    horizontalSlideMenu.horizontalBarTintColor = [UIColor whiteColor];
    horizontalSlideMenu.iconUnSelectedTintColor = [UIColor darkGrayColor];
    horizontalSlideMenu.iconSelectedTintColor = [UIColor whiteColor];
    horizontalSlideMenu.iconHighlitedTintColor = [UIColor whiteColor];
}
#pragma mark CollectionView

-(void)setUpCollectionView
{
    UICollectionViewFlowLayout *flowLayout = [[UICollectionViewFlowLayout alloc] init];
    flowLayout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
    temp = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:flowLayout];
    temp.pagingEnabled = YES;
    [temp registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:@"cellID"];
    temp.delegate = self;
    temp.dataSource = self;
    temp.backgroundColor = [UIColor blackColor];
}
#pragma mark CollectionviewDataSource
-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    UICollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"cellID" forIndexPath:indexPath];
    switch (indexPath.item)
    {
        case 0: cell.backgroundColor = [UIColor yellowColor];
            break;
        case 2: cell.backgroundColor = [UIColor blackColor];
            break;
        default: cell.backgroundColor = [UIColor blueColor];
            break;
    }
    return cell;
}
-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return 1;
}
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return 5;
}
-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    return CGSizeMake(self.view.frame.size.width, 400);
}

-(CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section
{
    return 0;
}
-(CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section
{
    return 0;
}

#pragma mark ScrollViewDelegate
-(void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    CGPoint contentOffSet = scrollView.contentOffset;
    [horizontalSlideMenu scrollBarWithContentOffSet:contentOffSet];
}

-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    CGPoint contentOffSet = scrollView.contentOffset;
    [horizontalSlideMenu scrollBarAndSelectItemWithContentOffSet:contentOffSet andWidthOfCell:self.view.frame.size.width];
}

#pragma mark HORIZONTALSLIDEMENU delegate, dataSource, flowLayout
-(UICollectionView *)setCollectionViewForMenuSlideBar
{
    return temp;
}

-(CGSize)sizeForIconAtItem:(NSInteger)item
{
    return CGSizeMake(25, 25);
}

-(NSArray *)arrOfIconsNamesForCells
{
    NSArray *arrTemp = @[@"1", @"2", @"3", @"4", @"5"];
    return arrTemp;
}
-(CGFloat)widthForBar
{
    return 5;
}
@end
