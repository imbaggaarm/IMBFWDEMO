//
//  ViewController.h
//  IMBFramework
//
//  Created by Dung Duong on 12/8/16.
//  Copyright © 2016 Tai Duong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

